
import math
import numpy as np
WeightBuffer=np.array([[0,2],
[ 2, 3]])

XBit=3
print("WeightBuffer=",WeightBuffer)


def DetectTheFirstValueOfRange(WeightBuffer):
	

	WeightBuffer1D=WeightBuffer.reshape(-1)
	print("WeightBuffer1D=",WeightBuffer1D)
	XWeightBuf1D=WeightBuffer1D.shape[0]
	print("XWeightBuf1D=",XWeightBuf1D)


    #change value of weightBuffer with the first value of each range
	i=0
	while i<XWeightBuf1D:
		print("WeightBuffer1D[",i,"]=",WeightBuffer1D[i])
		for x in range(4):
			print("(x/4)*(2**XBit)=",(x/4)*(2**XBit))
			print("((x+1)/4)*(2**XBit)=",((x+1)/4)*(2**XBit))
			if (WeightBuffer1D[i]>=((x/4)*(2**XBit))) &  (WeightBuffer1D[i]<(((x+1)/4)*(2**XBit))):
				#the first value of each range
				WeightBuffer1D[i]=((x/4)*(2**XBit))
				break
		i+=1
	print("WeightBuffer1D=",WeightBuffer1D)

	





DetectTheFirstValueOfRange(WeightBuffer)