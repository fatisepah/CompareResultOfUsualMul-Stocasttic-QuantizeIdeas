import pandas as pd

Weights = pd.read_excel('Compare-DecSum-In(5,5)-W(3,3)-2Q-5Bit-1000N.xlsx',sheet_name="WeightSheet")
Outputs = pd.read_excel('Compare-DecSum-In(5,5)-W(3,3)-2Q-5Bit-1000N.xlsx',sheet_name="OutputSheet")

DFWeights0 = pd.DataFrame(Weights, columns=['Weight[0]', 'First[0]'])



print(DFWeights0)


for row in range(0, DFWeights0.max_row):
    for col in DFWeights0.iter_cols(1, DFWeights0.max_column):
        print(col[row].value)