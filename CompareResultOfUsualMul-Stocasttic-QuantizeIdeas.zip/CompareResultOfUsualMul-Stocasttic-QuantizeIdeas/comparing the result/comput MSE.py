y = [11,20,19,17,10]
y_bar = [12,18,19.5,18,9]
summation = 0  
n = len(y) 
for i in range (0,n):  
  difference = y[i] - y_bar[i] 
  squared_difference = difference**2  
  summation = summation + squared_difference  
MSE = summation/n
print ("The Mean Square Error is: " , MSE)