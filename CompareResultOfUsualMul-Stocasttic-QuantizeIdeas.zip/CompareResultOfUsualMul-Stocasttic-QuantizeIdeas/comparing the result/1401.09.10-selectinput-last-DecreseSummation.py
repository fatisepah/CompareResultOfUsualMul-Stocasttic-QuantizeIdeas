#the most complete with image
XBit=3
QBit=2
sign=1
print("XBit:",XBit)


from PIL import Image
from numpy import array 
import numpy as np


# ImageInput = Image.open('C:\\Users\\ASUS\\Desktop\\ss\\Cat\\cat1.png').convert('L')
# InputBuffer = array(ImageInput)



# ImageWeight = Image.open('C:\\Users\\ASUS\\Desktop\\ss\\Cat\\eyecat1.png').convert('L')
# WeightBuffer = array(ImageWeight)


import numpy as np
InputBuffer=np.array([[3, 5 ,4,5],
[2, 1, 0,2],
[4, 3, 2,7],
[0, 4, 5,1]])


print("InputBuffer=",InputBuffer)


import numpy as np
WeightBuffer=np.array([[2,0,-2],
[2,5, 1],
[3,4, 0]])

print("WeightBuffer=",WeightBuffer)

XYInputBuf=InputBuffer.shape
XInputBuf= XYInputBuf[0]
YInputBuf= XYInputBuf[1]

#find dimention of weight buffer
XYWeightBuf=WeightBuffer.shape
XWBuf= XYWeightBuf[0]
YWBuf= XYWeightBuf[1]
lenWeight=len(WeightBuffer)

ArrayMulReshape=np.array([])
ListKeyWeight=[]
DicWeight={}
QTZRange=2**QBit

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def DetectTheLastValueOfRange(WeightBuffer):

	#reshape WeightSortArray to 1-D
	WeightBuffer1D=WeightBuffer.reshape(-1)
	print("WeightBuffer1D=",WeightBuffer1D)
	XWeightBuf1D=WeightBuffer1D.shape[0]


    #changing value of weightBuffer with the last value of each range
	i=0
	while i<XWeightBuf1D:		
		if WeightBuffer1D[i]<0:
			for x in range(QTZRange):
				Nfirst=((-(x+1)/QTZRange)*(2**XBit))-1
				Nlast=((-(x/QTZRange)*(2**XBit))-1)

				if (WeightBuffer1D[i]>Nfirst) &  (WeightBuffer1D[i]<=Nlast):
					#the last value of each range
					WeightBuffer1D[i]=Nlast
					break
		else:
			for x in range(QTZRange):
				Pfirst=((x/QTZRange)*(2**XBit))
				Plast=((x+1)/QTZRange)*(2**XBit)

				if (WeightBuffer1D[i]>=Pfirst) &  (WeightBuffer1D[i]<Plast):
					#the last value of each range
					WeightBuffer1D[i]=Plast-1
					break
		i+=1
	print("WB-DetectTheLastValueOfRange=",WeightBuffer1D)
	return WeightBuffer1D
     
#/////////////////////////////////////////////////////////////////////////////////////////////////////

def UpDownCounter(Enable,x,IncDec):
	IntX=int(x)
	Enable=int(Enable)

	if Enable != 0:
		if IntX == 1:
			if IncDec == 1:
				IntX=1
			else:
				IntX=-1
		else:
			IntX=0
	else:
		IntX=0
	return IntX

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def DownCounter(x):
 x-=1
 return x

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def BISC(In):
	 
	LenSc= 2 ** XBit
	
	sc=np.array([])
	
	for x in range(LenSc):
		sc=np.append(sc,[0])
		
	
	for x in range(XBit):
		i=(2 ** x)-1
		while i<LenSc:
			sc[i] = In[x]
			i+= 2 ** (x+1)
			
	sc = np.flip(sc)
	print("sc=",sc)
	
	return sc

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def DecimalToBinary(num,XBit):
	
	i = 0
	bnum = []
	Binary=''
	while num!=0:
		rem = num%2
		bnum.insert(i, rem)
		i = i+1
		num = int(num/2)
	i = i-1
	while i>=0:
		Binary=Binary+str(bnum[i])
		i = i-1
		
	while len(Binary)<XBit:
		Binary='0'+Binary
		
	print("Binary:",Binary)

	return Binary
  
#/////////////////////////////////////////////////////////////////////////////////////////////////////

def GetDefferentialWArray(w):
	DifferentialWArray=np.array([])
 

	#sort weight 1-D
	WeightSortArray1D=np.sort(w)
	print("WeightSortArray1D=",WeightSortArray1D)
	

	#create sorted weight array based on Differential of weights
	DifferentialWArray=np.append(DifferentialWArray,WeightSortArray1D[0])
	for x in range((XWBuf*YWBuf)-1):
		Differential=WeightSortArray1D[x+1]-WeightSortArray1D[x]
		DifferentialWArray=np.append(DifferentialWArray,Differential)
	print("DifferentialWArray=",DifferentialWArray)
	return DifferentialWArray

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def SortDicIndexWeight(w):

	for x in range(XWBuf):
		for y in range(YWBuf):
			str=x,y
			DicWeight[str]=w[x,y]
	
	#sort dic of weight baes on value:dic(key,value)
	DicWSort=dict(sorted(DicWeight.items(), key=lambda item: item[1]))
	print("DicWSort=",DicWSort)

	for x in range(XWBuf*YWBuf):
		ListKeyWeight.append(list(DicWSort.keys())[x])
	print("ListKeyWeight=",ListKeyWeight)






#/////////////////////////////////////////////////////////////////////////////////////////////////////





#function for doing the functional of PE in skippy based on BISC & Uo/Down counter & Down counter
def Mul(InputBuffer,WeightBuffer):
	OutputArray=np.array([])


	WeightBuffer1D=DetectTheLastValueOfRange(WeightBuffer)

	DifferentialW=GetDefferentialWArray(WeightBuffer1D)	

	SortDicIndexWeight(WeightBuffer)

	
	for x in range((XInputBuf-XWBuf)+1):
		for y in range((YInputBuf-YWBuf)+1):
			
			
			SelectIn=InputBuffer[x:XWBuf+x ,y:YWBuf+y]
			
			print("NewArray=",SelectIn)
			
			SumOut=0
			for a in range(XWBuf):
				for b in range(YWBuf):
					
					LenDiffW= len(DifferentialW)
					SumList=[]
					for s in range(LenDiffW):
						SumList.append(0)
						
					X=SelectIn[a,b]
					XBinary=DecimalToBinary(X,XBit)

					
					SC=BISC(XBinary)

					andisY=0
					for z in range(LenDiffW):
						andisSC=0
						
						ValWInDiff=DifferentialW[z]
						#print(type(ValWInDiff))
        


						if ValWInDiff == 0:
							if z==0:
								SumList[andisY]=0
							else:
								SumList[andisY]=SumList[andisY-1]
							andisY+=1
							continue						
						
	        			#instantiating the variable of sign holder 
						#if sign=0, number is negative & sign=1, number is positive
												
						if ValWInDiff<0:
							sign=0
							ValWInDiff=abs(ValWInDiff)
						else:
							sign=1
							

						
						sum=0
						while ValWInDiff>0:
							
							OutUDCounter=UpDownCounter(ValWInDiff,SC[(len(SC)-1)-andisSC],sign)
							andisSC+=1
							ValWInDiff=DownCounter(ValWInDiff)
							sum=sum+OutUDCounter
							
						if z==0:
							SumList[andisY]=sum
						else:
							SumList[andisY]=SumList[andisY-1]+sum
						andisY+=1
					

					print("SumList=",SumList)

					Index=ListKeyWeight.index((a,b))
					val=SumList[Index]
					print("ValIndex=",val)	
					SumOut=SumOut+val
					#for decrese the numbers of summation
					if SumOut >= (2**XBit):
						SumOut=2**XBit
						break					
			print("SumOut=",SumOut)

				

			OutputArray=np.append(OutputArray,SumOut)
			

	print("OutputArray=",OutputArray)
	NewOutputArray=OutputArray.reshape((XInputBuf-XWBuf)+1,(YInputBuf-YWBuf)+1)
	print("NewOutputArray=",NewOutputArray)
	return NewOutputArray


	


#/////////////////////////////////////////////////////////////////////////////////////////////

for x in range(10):
	s=Mul(InputBuffer,WeightBuffer)
	print("s=",s)



#for showing result using image
# data = Image.fromarray(s)
# data.show()


#/////////////////////////////////////////////////////////////////////////////////////////////////////



