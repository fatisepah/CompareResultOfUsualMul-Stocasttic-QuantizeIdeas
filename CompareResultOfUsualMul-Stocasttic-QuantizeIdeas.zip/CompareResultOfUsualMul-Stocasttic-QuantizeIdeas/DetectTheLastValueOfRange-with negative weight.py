
import math
import numpy as np
WeightBuffer=np.array([[2,7],
[ 4, -3]])

XBit=3

print("WeightBuffer=",WeightBuffer)


def DetectTheLastValueOfRange(WeightBuffer):
	

	WeightBuffer1D=WeightBuffer.reshape(-1)
	print("WeightBuffer1D=",WeightBuffer1D)
	XWeightBuf1D=WeightBuffer1D.shape[0]
	print("XWeightBuf1D=",XWeightBuf1D)


    #changing value of weightBuffer with the last value of each range
	i=0
	while i<XWeightBuf1D:
		print("WeightBuffer1D[",i,"]=",WeightBuffer1D[i])
		for x in range(4):
			if WeightBuffer1D[i]<0:
				print("The first value %d/4= %d" %(-(x+1),((-((x+2)/4)*(2**XBit))+1)))
				print("The last value %d/4= %d" %(-x,(((-((x+1)/4)*(2**XBit))+1))))
				if (WeightBuffer1D[i]>=(((-(x+2)/4)*(2**XBit))+1)) &  (WeightBuffer1D[i]<(((-((x+1)/4))*(2**XBit))+1)):
					#the last value of each range
					WeightBuffer1D[i]=(((-(x+1)/4)*(2**XBit))+1)
					break
			else:
				print("The first value %d/4= %d" %(x,(((x/4)*(2**XBit)))))
				print("The last value %d/4= %d" %((x+1),(((x+1)/4)*(2**XBit))))
				if (WeightBuffer1D[i]>=((x/4)*(2**XBit))) &  (WeightBuffer1D[i]<(((x+1)/4)*(2**XBit))):
					#the last value of each range
					WeightBuffer1D[i]=(((x+1)/4)*(2**XBit))
					break			

		i+=1
	print("WeightBuffer1D=",WeightBuffer1D)

	





DetectTheLastValueOfRange(WeightBuffer)