#the most complete with image
from PIL import Image
from numpy import array 
import numpy as np
import xlwt
import openpyxl
from numpy import random
import pandas as pd
from xlwt import Workbook
from openpyxl import load_workbook

#/////////////////////////////////////////////////////////////////////////////////////////////////////
def DetectTheFirstValueOfRange(WeightBuffer1D):
	WFirst=WeightBuffer1D.copy()

    #changing value of weightBuffer with the first value of each range
	i=0
	while i<XWeightBuf1D:
		if WFirst[i]<0:
			for x in range(QTZRange):
				Nfirst=((-(x+1)/QTZRange)*(2**XBit))-1
				Nlast=((-(x/QTZRange)*(2**XBit))-1)

				if (WFirst[i]>Nfirst) &  (WFirst[i]<=Nlast):
					#the first value of each range
					WFirst[i]=Nfirst+1
					break
		else:
			for x in range(QTZRange):
				Pfirst=((x/QTZRange)*(2**XBit))
				Plast=((x+1)/QTZRange)*(2**XBit)

				if (WFirst[i]>=Pfirst) &  (WFirst[i]<Plast):
					#the first value of each range
					WFirst[i]=Pfirst
					break
		i+=1
	# print("WB-DetectTheFirstValueOfRange=",WFirst)
	
	return WFirst
#/////////////////////////////////////////////////////////////////////////////////////////////////////
def DetectTheMidValueOfRange(WeightBuffer1D):
	WMid=WeightBuffer1D.copy()

    #changing value of weightBuffer with the mid value of each range
	i=0
	while i<XWeightBuf1D:
		if WMid[i]<0:
			for x in range(QTZRange):
				Nfirst=((-(x+1)/QTZRange)*(2**XBit))-1
				Nlast=((-(x/QTZRange)*(2**XBit))-1)

				if (WMid[i]>Nfirst) &  (WMid[i]<=Nlast):
					#the mid value of each range
					WMid[i]=(Nfirst+Nlast)/2
					break
		else:
			for x in range(QTZRange):
				Pfirst=((x/QTZRange)*(2**XBit))
				Plast=((x+1)/QTZRange)*(2**XBit)

				if (WMid[i]>=Pfirst) &  (WMid[i]<Plast):
					#the mid value of each range
					WMid[i]=(Pfirst+Plast)/2
					break
		i+=1
	# print("WB-DetectTheMidValueOfRange=",WMid)
	return WMid
#/////////////////////////////////////////////////////////////////////////////////////////////////////
def DetectTheLastValueOfRange(WeightBuffer1D):
	WLast=WeightBuffer1D.copy()
	
    #changing value of weightBuffer with the last value of each range
	i=0
	while i<XWeightBuf1D:		
		if WLast[i]<0:
			for x in range(QTZRange):
				Nfirst=((-(x+1)/QTZRange)*(2**XBit))-1
				Nlast=((-(x/QTZRange)*(2**XBit))-1)

				if (WLast[i]>Nfirst) &  (WLast[i]<=Nlast):
					#the last value of each range
					WLast[i]=Nlast
					break
		else:
			for x in range(QTZRange):
				Pfirst=((x/QTZRange)*(2**XBit))
				Plast=((x+1)/QTZRange)*(2**XBit)

				if (WLast[i]>=Pfirst) &  (WLast[i]<Plast):
					#the last value of each range
					WLast[i]=Plast-1
					break
		i+=1
	# print("WB-DetectTheLastValueOfRange=",WLast)
	return WLast
#/////////////////////////////////////////////////////////////////////////////////////////////////////


def UpDownCounter(Enable,x,IncDec):
	IntX=int(x)
	Enable=int(Enable)

	if Enable != 0:
		if IntX == 1:
			if IncDec == 1:
				IntX=1
			else:
				IntX=-1
		else:
			IntX=0
	else:
		IntX=0
	return IntX

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def DownCounter(x):
 x-=1
 return x

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def BISC(In):
	 
	LenSc= 2 ** XBit
	
	sc=np.array([])
	
	for x in range(LenSc):
		sc=np.append(sc,[0])
		
	
	for x in range(XBit):
		i=(2 ** x)-1
		while i<LenSc:
			sc[i] = In[x]
			i+= 2 ** (x+1)
			
	sc = np.flip(sc)
	# print("sc=",sc)
	
	return sc

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def DecimalToBinary(num,XBit):
	
	i = 0
	bnum = []
	Binary=''
	while num!=0:
		rem = num%2
		bnum.insert(i, rem)
		i = i+1
		num = int(num/2)
	i = i-1
	while i>=0:
		Binary=Binary+str(bnum[i])
		i = i-1
		
	while len(Binary)<XBit:
		Binary='0'+Binary
		
	# print("Binary:",Binary)

	return Binary
  
#/////////////////////////////////////////////////////////////////////////////////////////////////////

def GetDefferentialWArray(w):
	DifferentialWArray=np.array([])
 

	#sort weight 1-D
	WeightSortArray1D=np.sort(w)
	# print("WeightSortArray1D=",WeightSortArray1D)
	

	#create sorted weight array based on Differential of weights
	DifferentialWArray=np.append(DifferentialWArray,WeightSortArray1D[0])
	for x in range((XWBuf*YWBuf)-1):
		Differential=WeightSortArray1D[x+1]-WeightSortArray1D[x]
		DifferentialWArray=np.append(DifferentialWArray,Differential)
	# print("DifferentialWArray=",DifferentialWArray)
	return DifferentialWArray

#/////////////////////////////////////////////////////////////////////////////////////////////////////

def SortDicIndexWeight(w):

	w=w.reshape(XWBuf,YWBuf)

	for x in range(XWBuf):
		for y in range(YWBuf):
			str=x,y
			DicWeight[str]=w[x,y]
	
	#sort dic of weight baes on value:dic(key,value)
	DicWSort=dict(sorted(DicWeight.items(), key=lambda item: item[1]))
	# print("DicWSort=",DicWSort)

	for x in range(XWBuf*YWBuf):
		ListKeyWeight.append(list(DicWSort.keys())[x])
	# print("ListKeyWeight=",ListKeyWeight)


#/////////////////////////////////////////////////////////////////////////////////////////////////////


#function for doing the functional of PE in skippy based on BISC & Uo/Down counter & Down counter
def Mul(InputBuffer,WeightBuffer):
	OutputArray=np.array([])
	
	for x in range((XInputBuf-XWBuf)+1):
		for y in range((YInputBuf-YWBuf)+1):
			
			
			SelectIn=InputBuffer[x:XWBuf+x ,y:YWBuf+y]
			
			# print("NewArray=",SelectIn)
			
			SumOut=0
			for a in range(XWBuf):
				for b in range(YWBuf):
					
					LenDiffW= len(DifferentialW)
					SumList=[]
					for s in range(LenDiffW):
						SumList.append(0)
						
					X=SelectIn[a,b]
					XBinary=DecimalToBinary(X,XBit)

					
					SC=BISC(XBinary)

					andisY=0
					for z in range(LenDiffW):
						andisSC=0
						
						ValWInDiff=DifferentialW[z]
						#print(type(ValWInDiff))
        


						if ValWInDiff == 0:
							if z==0:
								SumList[andisY]=0
							else:
								SumList[andisY]=SumList[andisY-1]
							andisY+=1
							continue						
						
	        			#instantiating the variable of sign holder 
						#if sign=0, number is negative & sign=1, number is positive
												
						if ValWInDiff<0:
							sign=0
							ValWInDiff=abs(ValWInDiff)
						else:
							sign=1
							

						
						sum=0
						while ValWInDiff>0:
							
							OutUDCounter=UpDownCounter(ValWInDiff,SC[(len(SC)-1)-andisSC],sign)
							andisSC+=1
							ValWInDiff=DownCounter(ValWInDiff)
							sum=sum+OutUDCounter
							
						if z==0:
							SumList[andisY]=sum
						else:
							SumList[andisY]=SumList[andisY-1]+sum
						andisY+=1

					# print("SumList=",SumList)

					Index=ListKeyWeight.index((a,b))
					val=SumList[Index]
					# print("ValIndex=",val)	
					SumOut=SumOut+val
					#for decrese the numbers of summation
					if SumOut >= (2**XBit):
						SumOut=2**XBit
						break
					if SumOut <= -(2**XBit):
						SumOut=-(2**XBit)
						break
			# print("SumOut=",SumOut)

			#two lines for compute the last result baesd on stochastic(divide on 2**XBit)
			SumOut=SumOut/2**XBit
			# print("SumOut=",SumOut)

			OutputArray=np.append(OutputArray,SumOut)
			

	# print("OutputArray=",OutputArray)
	NewOutputArray=OutputArray.reshape((XInputBuf-XWBuf)+1,(YInputBuf-YWBuf)+1)
	# print("NewOutputArray=",NewOutputArray)
	return OutputArray


#/////////////////////////////////////////////////////////////////////////////////////////////

#create excel file
	 
wb = openpyxl.Workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")
wb.create_sheet(index=0,title="WeightSheet")
wb.create_sheet(index=1,title="OutputSheet")
wb.create_sheet(index=2,title="MSEW-FSheet")
wb.create_sheet(index=3,title="MSEW-MSheet")
wb.create_sheet(index=4,title="MSEW-LSheet")
wb.create_sheet(index=5,title="MSEOutS-FSheet")
wb.create_sheet(index=6,title="MSEOutS-MSheet")
wb.create_sheet(index=7,title="MSEOutS-LSheet")
wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')
Num=500

for x in range(Num):

	XBit=5
	QBit=2
	QTZRange=2**QBit
	sign=1
	# print("XBit:",XBit)
	
	# InputBuffer=np.array([[3, 5 ,4,5],
	# [2, 1, 0,2],
	# [4, 3, 2,7],
	# [0, 4, 5,1]])
	

	#code for randomize InputBuffer
	InputBuffer = random.randint(2**XBit, size=(5, 5))
	# print("InputBuffer=",InputBuffer)
	
	# WeightBuffer=np.array([[2,0,-2],
    # [2,5, 1],
    # [3,4, 0]])
	
	#code for randomize WeightBuffer
	# random.randint(low, high=None, size=None, dtype=int)
	WeightBuffer = random.randint(-2**XBit,high=2**XBit, size=(3, 3))
	# print("WeightBuffer=",WeightBuffer)
	
	XYInputBuf=InputBuffer.shape
	XInputBuf= XYInputBuf[0]
	YInputBuf= XYInputBuf[1]
    
    #find dimention of weight buffer
	XYWeightBuf=WeightBuffer.shape
	XWBuf= XYWeightBuf[0]
	YWBuf= XYWeightBuf[1]
	
	
	ArrayMulReshape=np.array([])
	Weights=np.array([])
	Outputs=np.array([])
	Out=np.array([])
	ListKeyWeight=[]
	DicWeight={}
	

	#reshape WeightSortArray to 1-D
	WeightBuffer1D=WeightBuffer.reshape(-1)
	Weights=np.append(Weights,WeightBuffer1D,axis=0)
	# print("WeightBuffer1D=",WeightBuffer1D)
	XWeightBuf1D=WeightBuffer1D.shape[0]

	#for apply WeightBuffer on skippy & Quantized numbers(First-Middle-Last)
	Weights=np.append(Weights,DetectTheFirstValueOfRange(WeightBuffer1D),axis=0)
	Weights=np.append(Weights,DetectTheMidValueOfRange(WeightBuffer1D),axis=0)
	Weights=np.append(Weights,DetectTheLastValueOfRange(WeightBuffer1D),axis=0)

#////////////////////////////////////////////////////////////////////////////////////////////////

	#save to excel file

	wb = load_workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")
	sheet=wb.worksheets[0]

	for z in range((4*XWBuf*YWBuf)+1):
		if z >= 0 and z<(XWBuf*YWBuf):
			NameW="Weight["+str(z)+"]"
			sheet.cell(1,z+1).value=NameW
		elif z>=(XWBuf*YWBuf) and z<(2*XWBuf*YWBuf):
			NameW1="First["+str(z-XWBuf*YWBuf)+"]"
			sheet.cell(1,z+1).value=NameW1
		elif z>=(2*XWBuf*YWBuf) and z<(3*XWBuf*YWBuf):
			NameW2="Middle["+str(z-2*XWBuf*YWBuf)+"]"
			sheet.cell(1,z+1).value=NameW2
		elif z>=(3*XWBuf*YWBuf) and z<(4*XWBuf*YWBuf):
			NameW3="Last["+str(z-3*XWBuf*YWBuf)+"]"
			sheet.cell(1,z+1).value=NameW3

	for a in range(4):
		for b in range(XWBuf*YWBuf):
			value=Weights[b+(a*(XWBuf*YWBuf))]
			sheet.cell(x+2,b+(a*(XWBuf*YWBuf)+1)).value=value


	wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')




#////////////////////////////////////////////////////////////////////////////////////////////////

	Weights=Weights.reshape(4,-1)
	# print("Weights=",Weights)

	for y in range(4):
		
		DifferentialW=GetDefferentialWArray(Weights[y])

		SortDicIndexWeight(Weights[y])	
		
		Out=Mul(InputBuffer,Weights[y])
		ListKeyWeight=[]

		Outputs=np.append(Outputs,Out,axis=0)

	Outputs=Outputs.reshape(4,-1)
	# print("Outputs=",Outputs)



#////////////////////////////////////////////////////////////////////////////////////////////////

	#save to excel file
	 
	#find dimention of output buffer
	DimOut=Out.shape[0]


	wb = load_workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")
	sheet1=wb.worksheets[1]


	for z in range((4*DimOut)+1):
		if z >= 0 and z<DimOut:
			NameO="Skippy["+str(z)+"]"
			sheet1.cell(1,z+1).value=NameO
		elif z>=DimOut and z<(2*DimOut):
			NameO1="First["+str(z-DimOut)+"]"
			sheet1.cell(1,z+1).value=NameO1
		elif z>=(2*DimOut) and z<(3*DimOut):
			NameO2="Middle["+str(z-2*DimOut)+"]"
			sheet1.cell(1,z+1).value=NameO2
		elif z>=(3*DimOut) and z<(4*DimOut):
			NameO3="Last["+str(z-3*DimOut)+"]"
			sheet1.cell(1,z+1).value=NameO3

	wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')

	wb = load_workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")
	sheet1=wb.worksheets[1]


	Outputs=Outputs.reshape(-1)

	for a in range(4):
		for b in range(DimOut):
			value=Outputs[b+(a*DimOut)]
			sheet1.cell(x+2,b+(a*DimOut+1)).value=value
			
	wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')

#///////////////////////////////////////////////////////////////////////////////////////////////////

WeightsDF = pd.read_excel('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx',sheet_name="WeightSheet")

wb = load_workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")

sheet2=wb.worksheets[2]
sheet3=wb.worksheets[3]
sheet4=wb.worksheets[4]



WeightsArray=np.asarray(WeightsDF)

# print(WeightsArray)



for x in range(XWBuf*YWBuf):
	NameF="W["+str(x)+"] - F["+str(x)+"]"
	sheet2.cell(1,x+2).value=NameF

	NameM="W["+str(x)+"] - M["+str(x)+"]"
	sheet3.cell(1,x+2).value=NameM

	NameL="W["+str(x)+"] - L["+str(x)+"]"
	sheet4.cell(1,x+2).value=NameL

sheet2.cell(2+Num,1).value='MSE'
sheet3.cell(2+Num,1).value='MSE'
sheet4.cell(2+Num,1).value='MSE'

sheet2.cell(4+Num,1).value='TotalMSE'
sheet3.cell(4+Num,1).value='TotalMSE'
sheet4.cell(4+Num,1).value='TotalMSE'

wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')

TotalSumAVGF=0
for x in range(XWBuf*YWBuf):
	SummationF=0
	AVGF=0
	for i in range(Num):
		SquareF=0
		DeffFirst=0
		val=0
		NameIndex=str(i+1)
		sheet2.cell(i+2,1).value=NameIndex
		val= WeightsArray[i,x]
		DeffFirst=val-WeightsArray[i,x+(XWBuf*YWBuf)]
		sheet2.cell(i+2,x+2).value=DeffFirst
		SquareF=DeffFirst**2
		SummationF+=SquareF
	AVGF=SummationF/Num
	TotalSumAVGF+=AVGF
	sheet2.cell(2+Num,2+x).value=AVGF
sheet2.cell(4+Num,2).value=TotalSumAVGF/(XWBuf*YWBuf)


TotalSumAVGM=0
for x in range(XWBuf*YWBuf):
	SummationM=0
	AVGM=0
	for i in range(Num):
		SquareM=0
		DeffMid=0
		val=0
		NameIndex=str(i+1)
		sheet3.cell(i+2,1).value=NameIndex
		val= WeightsArray[i,x]
		DeffMid=val-WeightsArray[i,x+2*(XWBuf*YWBuf)]
		sheet3.cell(i+2,x+2).value=DeffMid
		SquareM=DeffMid**2
		SummationM+=SquareM
	AVGM=SummationM/Num
	TotalSumAVGM+=AVGM
	sheet3.cell(2+Num,2+x).value=AVGM
sheet3.cell(4+Num,2).value=TotalSumAVGM/(XWBuf*YWBuf)

TotalSumAVGL=0
for x in range(XWBuf*YWBuf):	
	SummationL=0
	AVGL=0
	for i in range(Num):
		SquareL=0
		DeffLast=0
		val=0		
		NameIndex=str(i+1)
		sheet4.cell(i+2,1).value=NameIndex
		val= WeightsArray[i,x]
		DeffLast=val-WeightsArray[i,x+3*(XWBuf*YWBuf)]
		sheet4.cell(i+2,x+2).value=DeffLast
		SquareL=DeffLast**2
		SummationL+=SquareL
	AVGL=SummationL/Num
	TotalSumAVGL+=AVGL
	sheet4.cell(2+Num,2+x).value=AVGL
sheet4.cell(4+Num,2).value=TotalSumAVGL/(XWBuf*YWBuf)

wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')


#////////////////////////////////////////////////////////////////////////////////////////////////

OutputsDF = pd.read_excel('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx',sheet_name="OutputSheet")

wb = load_workbook("DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx")
sheet5=wb.worksheets[5]
sheet6=wb.worksheets[6]
sheet7=wb.worksheets[7]


OutputsArray=np.asarray(OutputsDF)

# print(OutputsArray)



for x in range(DimOut):
	NameF="S["+str(x)+"] - F["+str(x)+"]"
	sheet5.cell(1,x+2).value=NameF

	NameM="S["+str(x)+"] - M["+str(x)+"]"
	sheet6.cell(1,x+2).value=NameM

	NameL="S["+str(x)+"] - L["+str(x)+"]"
	sheet7.cell(1,x+2).value=NameL

sheet5.cell(2+Num,1).value='MSE'
sheet6.cell(2+Num,1).value='MSE'
sheet7.cell(2+Num,1).value='MSE'

sheet5.cell(4+Num,1).value='TotalMSE'
sheet6.cell(4+Num,1).value='TotalMSE'
sheet7.cell(4+Num,1).value='TotalMSE'

wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')

TotalSumAVGOutF=0
for x in range(DimOut):
	SummationOutF=0
	AVGOutF=0
	for i in range(Num):
		SquareOutF=0
		DeffOutFirst=0
		val=0
		NameIndex=str(i+1)
		sheet5.cell(i+2,1).value=NameIndex
		val= OutputsArray[i,x]
		DeffOutFirst=val-OutputsArray[i,x+DimOut]
		sheet5.cell(i+2,x+2).value=DeffOutFirst
		SquareOutF=DeffOutFirst**2
		SummationOutF+=SquareOutF
	AVGOutF=SummationOutF/Num
	TotalSumAVGOutF+=AVGOutF
	sheet5.cell(2+Num,2+x).value=AVGOutF
sheet5.cell(4+Num,2).value=TotalSumAVGOutF/DimOut

TotalSumAVGOutM=0
for x in range(DimOut):
	SummationOutM=0
	AVGOutM=0
	for i in range(Num):
		SquareOutM=0
		DeffOutMid=0
		val=0
		NameIndex=str(i+1)
		sheet6.cell(i+2,1).value=NameIndex
		val= OutputsArray[i,x]
		DeffOutMid=val-OutputsArray[i,x+2*DimOut]
		sheet6.cell(i+2,x+2).value=DeffOutMid
		SquareOutM=DeffOutMid**2
		SummationOutM+=SquareOutM
	AVGOutM=SummationOutM/Num
	TotalSumAVGOutM+=AVGOutM
	sheet6.cell(2+Num,2+x).value=AVGOutM
sheet6.cell(4+Num,2).value=TotalSumAVGOutM/DimOut


TotalSumAVGOutL=0
for x in range(DimOut):	
	SummationOutL=0
	AVGOutL=0
	for i in range(Num):
		SquareOutL=0
		DeffOutLast=0
		val=0		
		NameIndex=str(i+1)
		sheet7.cell(i+2,1).value=NameIndex
		val= OutputsArray[i,x]
		DeffOutLast=val-OutputsArray[i,x+3*DimOut]
		sheet7.cell(i+2,x+2).value=DeffOutLast
		SquareOutL=DeffOutLast**2
		SummationOutL+=SquareOutL
	AVGOutL=SummationOutL/Num
	TotalSumAVGOutL+=AVGOutL
	sheet7.cell(2+Num,2+x).value=AVGOutL
sheet7.cell(4+Num,2).value=TotalSumAVGOutL/DimOut


wb.save('DecSum-MSEInSheets-In(5,5)-W(3,3)-2Q-5Bit-500N.xlsx')



		

#/////////////////////////////////////////////////////////////////////////////////////////////////////



