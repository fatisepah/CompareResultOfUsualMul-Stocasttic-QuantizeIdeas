import math
import numpy as np
WeightBuffer=np.array([[2,7],
[ 18, 10]])

print("WeightBuffer=",WeightBuffer)


def DetectTheMidValueOfRange(WeightBuffer):

	WeightBuffer1D=WeightBuffer.reshape(-1)
	print("WeightBuffer1D=",WeightBuffer1D)
	XWeightBuf1D=WeightBuffer1D.shape[0]
	print("XWeightBuf1D=",XWeightBuf1D)


	LargestNumber=WeightBuffer1D[0]

	#find the largest number in weight buffer
	for x in range(1,XWeightBuf1D):
		if LargestNumber<WeightBuffer1D[x]:
			LargestNumber=WeightBuffer1D[x]
	print("LargestNumber=",LargestNumber)

	#find the require bit for range detection
	XBit1=math.log2(LargestNumber)
	XBit=math.ceil(math.log2(LargestNumber))
	print("XBit=",XBit)

    #change value of weightBuffer with the mid value of each range
	i=0
	while i<XWeightBuf1D:
		print("WeightBuffer1D[",i,"]=",WeightBuffer1D[i])
		for x in range(4):
			print("(x/4)*(2**XBit)=",(x/4)*(2**XBit))
			print("((x+1)/4)*(2**XBit)=",((x+1)/4)*(2**XBit))
			if (WeightBuffer1D[i]>=((x/4)*(2**XBit))) &  (WeightBuffer1D[i]<(((x+1)/4)*(2**XBit))):
				#the mid value of each range
				WeightBuffer1D[i]=math.ceil((((x/4)*(2**XBit))+(((x+1)/4)*(2**XBit)))/2)
				break
		i+=1
	print("WeightBuffer1D=",WeightBuffer1D)

	





DetectTheMidValueOfRange(WeightBuffer)