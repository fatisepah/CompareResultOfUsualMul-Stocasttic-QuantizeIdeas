#the most complete with image
XBit=5
sign=1
print("XBit:",XBit)


from PIL import Image
from numpy import array 
import numpy as np
from numpy import random



import numpy as np
InputBuffer=np.array([[3, 5 ,4,5],
[2, 1, 0,2],
[4, 3, 2,7],
[0, 4, 5,1]])


print("InputBuffer=",InputBuffer)


import numpy as np
WeightBuffer=np.array([[2,0,-2],
[2,5, 1],
[3,4, 0]])

print("WeightBuffer=",WeightBuffer)

XYInputBuf=InputBuffer.shape
XInputBuf= XYInputBuf[0]
YInputBuf= XYInputBuf[1]

#find dimention of weight buffer
XYWeightBuf=WeightBuffer.shape
XWBuf= XYWeightBuf[0]
YWBuf= XYWeightBuf[1]



#/////////////////////////////////////////////////////////////////////////////////////////////////////


#function for doing the functional of PE in skippy based on BISC & Uo/Down counter & Down counter
def UsualMul(InputBuffer,WeightBuffer):
	OutputArray=np.array([])
	
	for x in range((XInputBuf-XWBuf)+1):
		for y in range((YInputBuf-YWBuf)+1):

			SelectIn=InputBuffer[x:XWBuf+x ,y:YWBuf+y]
			
			print("NewArray=",SelectIn)
			
			SumOut=0
			for a in range(XWBuf):
				for b in range(YWBuf):
						
					ValIn=SelectIn[a,b]
					ValW=WeightBuffer[a,b]

					SumOut+=ValIn*ValW
			print("SumOut=",SumOut)
			SumOut=SumOut/(2**(2*XBit))
			
			OutputArray=np.append(OutputArray,SumOut)
			
	return OutputArray


	


#/////////////////////////////////////////////////////////////////////////////////////////////


s=UsualMul(InputBuffer,WeightBuffer)
print("s=",s)



#/////////////////////////////////////////////////////////////////////////////////////////////////////



