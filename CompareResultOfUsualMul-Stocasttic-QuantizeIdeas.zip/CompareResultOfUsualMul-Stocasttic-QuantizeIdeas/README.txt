To do this, first, the Forward function of the Convolution layer is implemented in the form of normal multiplication and multiplication based on Stochastic calculations, and at the same time, matrices for Input and Weight are given to both of these functions, and MSE (Mean Square Error) is calculated compared to normal multiplication. And this has been done for 500 matrices, and all these matrices have been entered into the Excel environment at the same time, based on the written codes, and the results have been calculated and the MSE has been calculated.



برای انجام اینکار، ابتدا تابع 
Forward 
لایه 
Convolution 
را به صورت ضرب عادی و ضرب براساس محاسبات 
Stochastic 
پیاده کرده و همزمان ماتریس هایی را برای 
Input و Weight 
به هر دوی این توابع داده شده و 
MSE(Mean Square Error) 
نسبت به ضرب عادی محاسبه شده و برای 500 ماتریس اینکار انجام شده که تمام این ماتریس ها همزمان و براساس کدهای نوشته شده و به صورت خودکار
 به محیط 
Excel 
وارد شده است و و نتایج محاسبه شده و 
MSE 
هم محاسبه شده است.